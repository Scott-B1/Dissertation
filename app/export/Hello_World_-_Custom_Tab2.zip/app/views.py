from app import app
from flask import render_template


@app.route('/')
@app.route('/index')
def index():
    return render_template('mainmenu.html')

@app.route('/choose_custom_dsm')
def choose_custom_dsm():
    return render_template('choose_custom.html')
    
@app.route('/custom_dsm')
def custom_dsm():
    return render_template('custom.html')
    
@app.route('/choose_sample')
def choose_sample():
    return render_template('choose_sample.html')
    
@app.route('/sample')
def sample():
    return render_template('sample.html')
    
@app.route('/update')
def update():
    return render_template('update.html')