import __builtin__
import qpylib
__author__ = 'IBM'
__version__ = '0.10+0d862af1b2056a3ec51bb14c068c04d0a01f167b'

__builtin__.get_app_base_url = qpylib.get_app_base_url
__builtin__.q_url_for = qpylib.q_url_for
